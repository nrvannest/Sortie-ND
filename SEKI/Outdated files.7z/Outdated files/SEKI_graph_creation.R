##Graphs associated with SEKI_df_creation doc
#Pulled and organized from SEKI_analysis_updated

seki_data <- read.table("SEKI_future_data.txt", sep = "\t")

#Paper fig 1, 2, and 3  
multiplot(SP.QUKE.Dens.plot , SP.PIPO.Dens.plot ,SP.Dens.CNTRL.plot, SP.Dens.MIROC.plot, cols=2)
multiplot(SJP.PIJE.BA.plot ,SJP.ABCO.BA.plot , SJP.BA.CNTRL.plot, SJP.BA.MIROC.plot, cols=2)
multiplot(SP.QUKE.BA.plot , SP.PIPO.BA.plot ,SP.BA.CNTRL.plot, SP.BA.MIROC.plot, cols =2)

seki_data %>% 
  mutate(ba_dens = melt(id))

seki_data %>% 
  filter(Plot == "SP",
         Species %in% c("QUKE"),
         variable %in% c("CNRM_Dens", "CCSM4_Dens", "MIROC_Dens", "CNTRL_Dens")) %>% 
  group_by(variable) %>% 
  ggplot(aes(x = Year)) +
  geom_line(aes(y = sequence, color = variable),
            show.legend = F) +
  geom_dl(aes(label = variable, color = variable, y = sequence), method = list(dl.trans(x = x + 0), "last.points", cex = 0.8, hjust = -.1)) +
  theme(plot.margin = unit(c(1,3,1,1), "lines")) +
  xlim(2008, 2115) +
  geom_ribbon(
    aes(
      x = Year,
      ymin = grep("2.5", seki_data$variable),
      ymax = grep("97.5"),
      group = variable
    ))










#######GRAPHS###########################################################

########SJ BA############



SJ.ABCO.BA.plot <- ggplot(SJ.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend =
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ ABCO")

SJ.ABMA.BA.plot <- ggplot(SJ.ABMA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ ABMA")

SJ.PIJE.BA.plot <- ggplot(SJ.PIJE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ PIJE")

SJ.PILA.BA.plot <- ggplot(SJ.PILA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ PILA")

ggsave("SJ.BA.ABCO.png", SJ.ABCO.BA.plot)
ggsave("SJ.BA.ABMA.png", SJ.ABMA.BA.plot)
ggsave("SJ.BA.PIJE.png", SJ.PIJE.BA.plot)
ggsave("SJ.BA.PILA.png", SJ.PILA.BA.plot)
#######################SJ Density##########################

SJ.ABCO.Dens.plot <- ggplot(SJ.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ ABCO")

SJ.ABMA.Dens.plot <- ggplot(SJ.ABMA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ ABMA")

SJ.PIJE.Dens.plot <- ggplot(SJ.PIJE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ PIJE")

SJ.PILA.Dens.plot <- ggplot(SJ.PILA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJ PILA")

ggsave("SJ.Dens.ABCO.png", SJ.ABCO.Dens.plot)
ggsave("SJ.Dens.ABMA.png", SJ.ABMA.Dens.plot)
ggsave("SJ.Dens.PIJE.png", SJ.PIJE.Dens.plot)
ggsave("SJ.Dens.PILA.png", SJ.PILA.Dens.plot)

############SJP Graphs#################################

########SJP BA############

SJP.ABCO.BA.plot <- ggplot(SJP.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP ABCO")

SJP.ABMA.BA.plot <- ggplot(SJP.ABMA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP ABMA")

SJP.PIJE.BA.plot <- ggplot(SJP.PIJE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP PIJE")

SJP.PILA.BA.plot <- ggplot(SJP.PILA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP PILA")

SJP.PIPO.BA.plot <- ggplot(SJP.PIPO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP PIPO")

SJP.CADE.BA.plot <- ggplot(SJP.CADE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP CADE")

ggsave("SJP.BA.ABCO.png", SJP.ABCO.BA.plot)
ggsave("SJP.BA.ABMA.png", SJP.ABMA.BA.plot)
ggsave("SJP.BA.PIJE.png", SJP.PIJE.BA.plot)
ggsave("SJP.BA.PILA.png", SJP.PILA.BA.plot)
ggsave("SJP.BA.PIPO.png", SJP.PIPO.BA.plot)
ggsave("SJP.BA.CADE.png", SJP.CADE.BA.plot)
#######################SJP Density##########################

SJP.ABCO.Dens.plot <- ggplot(SJP.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP ABCO")

SJP.ABMA.Dens.plot <- ggplot(SJP.ABMA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP ABMA")

SJP.PIJE.Dens.plot <- ggplot(SJP.PIJE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP PIJE")

SJP.PILA.Dens.plot <- ggplot(SJP.PILA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP PILA")

SJP.CADE.Dens.plot <- ggplot(SJP.CADE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP CADE")

SJP.PIPO.Dens.plot <- ggplot(SJP.PIPO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJP PIPO")

ggsave("SJP.Dens.ABCO.png", SJP.ABCO.Dens.plot)
ggsave("SJP.Dens.ABMA.png", SJP.ABMA.Dens.plot)
ggsave("SJP.Dens.PIJE.png", SJP.PIJE.Dens.plot)
ggsave("SJP.Dens.PILA.png", SJP.PILA.Dens.plot)
ggsave("SJP.Dens.PIPO.png", SJP.PIPO.Dens.plot)
ggsave("SJP.Dens.CADE.png", SJP.CADE.Dens.plot)

#######################SJM Graphs#################################
########SJM BA############

SJM.ABCO.BA.plot <- ggplot(SJM.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM ABCO")

SJM.ABMA.BA.plot <- ggplot(SJM.ABMA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM ABMA")

SJM.PICO.BA.plot <- ggplot(SJM.PICO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM PICO")

SJM.PIMO.BA.plot <- ggplot(SJM.PIMO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM PIMO")

ggsave("SJM.BA.ABCO.png", SJM.ABCO.BA.plot)
ggsave("SJM.BA.ABMA.png", SJM.ABMA.BA.plot)
ggsave("SJM.BA.PICO.png", SJM.PICO.BA.plot)
ggsave("SJM.BA.PIMO.png", SJM.PIMO.BA.plot)

#######################SJM Density##########################

SJM.ABCO.Dens.plot <- ggplot(SJM.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM ABCO")

SJM.ABMA.Dens.plot <- ggplot(SJM.ABMA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM ABMA")

SJM.PICO.Dens.plot <- ggplot(SJM.PICO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM PICO")


SJM.PIMO.Dens.plot <- ggplot(SJM.PIMO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SJM PIMO")

ggsave("SJM.Dens.ABCO.png", SJM.ABCO.Dens.plot)
ggsave("SJM.Dens.ABMA.png", SJM.ABMA.Dens.plot)
ggsave("SJM.Dens.PICO.png", SJM.PICO.Dens.plot)
ggsave("SJM.Dens.PIMO.png", SJM.PIMO.Dens.plot)

#######################SP Graphs##################################

########SP BA############

SP.ABCO.BA.plot <- ggplot(SP.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP ABCO")

SP.CADE.BA.plot <- ggplot(SP.CADE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP CADE")

SP.PILA.BA.plot <- ggplot(SP.PILA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP PILA")

SP.PIPO.BA.plot <- ggplot(SP.PIPO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP PIPO")

SP.QUCH.BA.plot <- ggplot(SP.QUCH.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP QUCH")


SP.QUKE.BA.plot <- ggplot(SP.QUKE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_BA, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_BA,
      ymax = CCSM4_97.5_BA,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_BA, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_BA,
      ymax = CNRM_97.5_BA,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_BA, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_BA,
      ymax = MIROC_97.5_BA,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_BA, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_BA,
      ymax = CNTRL_97.5_BA,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Basal Area", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP QUKE")

ggsave("SP.BA.ABCO.png", SP.ABCO.BA.plot)
ggsave("SP.BA.CADE.png", SP.CADE.BA.plot)
ggsave("SP.BA.PIPO.png", SP.PIPO.BA.plot)
ggsave("SP.BA.PILA.png", SP.PILA.BA.plot)
ggsave("SP.BA.QUKE.png", SP.QUKE.BA.plot)
#######################SP Density##########################

SP.ABCO.Dens.plot <- ggplot(SP.ABCO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP ABCO")

SP.CADE.Dens.plot <- ggplot(SP.CADE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP CADE")

SP.PIPO.Dens.plot <- ggplot(SP.PIPO.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP PIPO")

SP.PILA.Dens.plot <- ggplot(SP.PILA.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP PILA")

SP.QUCH.Dens.plot <- ggplot(SP.QUCH.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP QUCH")

SP.QUKE.Dens.plot <- ggplot(SP.QUKE.df, aes(x = Year)) +
  geom_line(aes(y = CCSM4_Dens, colour = "CCSM4")) +
  geom_ribbon(
    aes(
      ymin = CCSM4_2.5_Dens,
      ymax = CCSM4_97.5_Dens,
      fill = "CCSM4"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNRM_Dens, colour = "CNRM")) +
  geom_ribbon(
    aes(
      ymin = CNRM_2.5_Dens,
      ymax = CNRM_97.5_Dens,
      fill = "CNRM"
    ),
    alpha = 0.1,
    show.legend = F
  )  +
  geom_line(aes(y = MIROC_Dens, colour = "MIROC")) +
  geom_ribbon(
    aes(
      ymin = MIROC_2.5_Dens,
      ymax = MIROC_97.5_Dens,
      fill = "MIROC"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  geom_line(aes(y = CNTRL_Dens, colour = "CNTRL")) +
  geom_ribbon(
    aes(
      ymin = CNTRL_2.5_Dens,
      ymax = CNTRL_97.5_Dens,
      fill = "CNTRL"
    ),
    alpha = 0.1,
    show.legend = F
  ) +
  labs(y = "Density", colour = "Climate Sequence") +
  scale_x_continuous(breaks = pretty_breaks(n = 5)) +
  ggtitle("SP QUKE")

ggsave("SP.Dens.ABCO.png", SP.ABCO.Dens.plot)
ggsave("SP.Dens.ABMA.png", SP.ABMA.Dens.plot)
ggsave("SP.Dens.PIPO.png", SP.PIPO.Dens.plot)
ggsave("SP.Dens.PILA.png", SP.PILA.Dens.plot)
ggsave("SP.Dens.QUKE.png", SP.QUKE.Dens.plot)