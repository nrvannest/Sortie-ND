##Creation and synthesis of data frames associated with SEKI_graph_creation doc
#Pulled and organized from SEKI_analysis_updated

plots <- c("SJM", "SJ", "SP", "SJP")
runs <- 10
timesteps <- 92
species <- c("ABCO","CADE" ,"PILA", "PIPO" ,"QUCH" ,"QUKE", "PICO" ,"PIMO", "PIJE", "ABMA")
clim_seqs<- c("CCSM4", "CNRM", "MIROC", "CNTRL")
library(tidyverse)
library(directlabels)
library(gridExtra)
library(data.table)
library(scales)
library(reshape2)
##############Function to extract adult and sapling basal area###################
###Use site in quotes and caps to get info ie: "SJM"

Basal_area <- function(site, clim_seq){
  results <- array(data = NA, dim = c(runs, length(species), timesteps + 1))
  dimnames(results)[2] <- list(species)
  dimnames(results)[3] <- list(1:(timesteps + 1))
  
  for (i in 1:runs){   
    our_file <- paste0(site, "/", site, "_", clim_seq, "_", i,".out")
    data1 <- read.table(file = our_file,skip=6,header=TRUE,sep = "\t")
    data <- data1[data1$Subplot == 1,] ### Subplot #1 is the extracted center 100m x 100m
    
    for (who in species){ # tree = Sapl + Adult
      results[i, who, ] <- data[,paste("Adult.Abs.BA.",who,sep=".")] + 
        data[ , paste("Sapl.Abs.BA.", who, sep=".")]
    }
  }
  return(results)
}
#####################Function to extract adult and sapling density####################
Density <- function(site, clim_seq){
  results <- array(data = NA, dim = c(runs, length(species), timesteps + 1))
  dimnames(results)[2] <- list(species)
  dimnames(results)[3] <- list(1:(timesteps + 1))
  
  for (i in 1:runs){
    our_file <- paste0(site, "/", site, "_", clim_seq, "_", i,".out")
    data1 <- read.table(file = our_file,skip=6,header=TRUE,sep = "\t")
    data <- data1[data1$Subplot == 1,] ### Subplot #1 is the extracted center 100m x 100m
    
    for (who in species){ # tree = Sapl + Adult
      results[i, who, ] <- data[,paste("Adult.Abs.Den.",who,sep=".")] + 
        data[ , paste("Sapl.Abs.Den.", who, sep=".")]
    }
  }
  return(results)
}

###########Analyzing the data#########################

Years_sim <- 2007:2099

################Median#############################
###Function to find the median basal area for each species for each timestep within each site

Median_BA <- function(site, clim_seq){
  Median_BA <- matrix(NA, nrow = length(species), ncol = timesteps + 1)
  rownames(Median_BA) <- species
  for(i in species){
    temp <- apply(Basal_area(site, clim_seq)[, i, ], 2, median)
    Median_BA[i, ] <- round(temp, 3)
  }
  
  Median <- Median_BA[which(rowSums(Median_BA) > 0),]
  Median_BA <- transpose(as.data.frame(Median))
  colnames(Median_BA) <- rownames(Median)
  Median_BA <- cbind(data.frame("Years" = Years_sim), Median_BA)
  
  return(Median_BA)
}

###Function to find the median density for each species for each timestep within each site

Median_Dens <- function(site, clim_seq){
  Median_Dens <- matrix(NA, nrow = length(species), ncol = timesteps + 1)
  rownames(Median_Dens) <- species
  for(i in species){
    temp <- apply(Density(site, clim_seq)[, i, ], 2, median)
    Median_Dens[i, ] <- round(temp, 3)
  }
  
  Median <- Median_Dens[which(rowSums(Median_Dens) > 0),]
  Median_Dens <- transpose(as.data.frame(Median))
  colnames(Median_Dens) <- rownames(Median)
  Median_Dens <- cbind(data.frame("Years" = Years_sim), Median_Dens)
  
  return(Median_Dens)
}


######################Quantile######################

Quant_BA <- function(site, clim_seq){
  Quant_BA <- matrix(0, 1, ncol = timesteps + 1)
  for(i in species){
    temp <- apply(Basal_area(site, clim_seq)[,i,],2,quantile,c(0.025,0.975))
    temp <- round(temp, 3)
    rownames(temp) <- c(paste0(i, " 2.5%"), paste0(i, " 97.5%"))
    Quant_BA <- rbind(temp, Quant_BA)
  }
  Quant_BA_temp <- Quant_BA[which(rowSums(Quant_BA) > 0), ]
  Quant_BA <- transpose(as.data.frame(Quant_BA_temp))
  colnames(Quant_BA) <- rownames(Quant_BA_temp)
  Quant_BA <- cbind(data.frame("Years" = Years_sim), Quant_BA)
  
  return(Quant_BA)
}



###
Quant_Dens <- function(site, clim_seq){
  Quant_Dens <- matrix(0, 1, ncol = timesteps + 1)
  for(i in species){
    temp <- apply(Density(site, clim_seq)[,i,],2,quantile,c(0.025,0.975))
    temp <- round(temp, 3)
    rownames(temp) <- c(paste0(i, " 2.5%"), paste0(i, " 97.5%"))
    Quant_Dens <- rbind(temp, Quant_Dens)
  }
  Quant_Dens_temp <- Quant_Dens[which(rowSums(Quant_Dens) > 0), ]
  Quant_Dens <- transpose(as.data.frame(Quant_Dens_temp))
  colnames(Quant_Dens) <- rownames(Quant_Dens_temp)
  Quant_Dens <- cbind(data.frame("Years" = Years_sim), Quant_Dens)
  
  return(Quant_Dens)
}

#####################By site all sequences one species################
#SJ : ABCO, ABMA, PIJE, PILA

SJ.ABCO.df <- data.frame("Year" = Median_BA("SJ", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SJ", "CCSM4")[, "ABCO"],
                         "CCSM4_Dens" = Median_Dens("SJ", "CCSM4")[, "ABCO"],
                         "CCSM4_2.5_BA" = Quant_BA("SJ", "CCSM4")[, "ABCO 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "ABCO 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SJ", "CCSM4")[, "ABCO 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "ABCO 97.5%"],
                         "CNRM_BA" = Median_BA("SJ", "CNRM")[, "ABCO"],
                         "CNRM_Dens" = Median_Dens("SJ", "CNRM")[, "ABCO"],
                         "CNRM_2.5_BA" = Quant_BA("SJ", "CNRM")[, "ABCO 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SJ", "CNRM")[, "ABCO 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SJ", "CNRM")[, "ABCO 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SJ", "CNRM")[, "ABCO 97.5%"],
                         "MIROC_BA" = Median_BA("SJ", "MIROC")[, "ABCO"],
                         "MIROC_Dens" = Median_Dens("SJ", "MIROC")[, "ABCO"],
                         "MIROC_2.5_BA" = Quant_BA("SJ", "MIROC")[, "ABCO 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SJ", "MIROC")[, "ABCO 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SJ", "MIROC")[, "ABCO 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SJ", "MIROC")[, "ABCO 97.5%"],
                         "CNTRL_BA" = Median_BA("SJ", "CNTRL")[, "ABCO"],
                         "CNTRL_Dens" = Median_Dens("SJ", "CNTRL")[, "ABCO"],
                         "CNTRL_2.5_BA" = Quant_BA("SJ", "CNTRL")[, "ABCO 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "ABCO 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SJ", "CNTRL")[, "ABCO 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "ABCO 97.5%"])

SJ.ABMA.df <- data.frame("Year" = Median_BA("SJ", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SJ", "CCSM4")[, "ABMA"],
                         "CCSM4_Dens" = Median_Dens("SJ", "CCSM4")[, "ABMA"],
                         "CCSM4_2.5_BA" = Quant_BA("SJ", "CCSM4")[, "ABMA 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "ABMA 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SJ", "CCSM4")[, "ABMA 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "ABMA 97.5%"],
                         "CNRM_BA" = Median_BA("SJ", "CNRM")[, "ABMA"],
                         "CNRM_Dens" = Median_Dens("SJ", "CNRM")[, "ABMA"],
                         "CNRM_2.5_BA" = Quant_BA("SJ", "CNRM")[, "ABMA 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SJ", "CNRM")[, "ABMA 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SJ", "CNRM")[, "ABMA 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SJ", "CNRM")[, "ABMA 97.5%"],
                         "MIROC_BA" = Median_BA("SJ", "MIROC")[, "ABMA"],
                         "MIROC_Dens" = Median_Dens("SJ", "MIROC")[, "ABMA"],
                         "MIROC_2.5_BA" = Quant_BA("SJ", "MIROC")[, "ABMA 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SJ", "MIROC")[, "ABMA 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SJ", "MIROC")[, "ABMA 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SJ", "MIROC")[, "ABMA 97.5%"],
                         "CNTRL_BA" = Median_BA("SJ", "CNTRL")[, "ABMA"],
                         "CNTRL_Dens" = Median_Dens("SJ", "CNTRL")[, "ABMA"],
                         "CNTRL_2.5_BA" = Quant_BA("SJ", "CNTRL")[, "ABMA 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "ABMA 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SJ", "CNTRL")[, "ABMA 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "ABMA 97.5%"])


SJ.PIJE.df <- data.frame("Year" = Median_BA("SJ", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SJ", "CCSM4")[, "PIJE"],
                         "CCSM4_Dens" = Median_Dens("SJ", "CCSM4")[, "PIJE"],
                         "CCSM4_2.5_BA" = Quant_BA("SJ", "CCSM4")[, "PIJE 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "PIJE 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SJ", "CCSM4")[, "PIJE 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "PIJE 97.5%"],
                         "CNRM_BA" = Median_BA("SJ", "CNRM")[, "PIJE"],
                         "CNRM_Dens" = Median_Dens("SJ", "CNRM")[, "PIJE"],
                         "CNRM_2.5_BA" = Quant_BA("SJ", "CNRM")[, "PIJE 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SJ", "CNRM")[, "PIJE 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SJ", "CNRM")[, "PIJE 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SJ", "CNRM")[, "PIJE 97.5%"],
                         "MIROC_BA" = Median_BA("SJ", "MIROC")[, "PIJE"],
                         "MIROC_Dens" = Median_Dens("SJ", "MIROC")[, "PIJE"],
                         "MIROC_2.5_BA" = Quant_BA("SJ", "MIROC")[, "PIJE 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SJ", "MIROC")[, "PIJE 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SJ", "MIROC")[, "PIJE 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SJ", "MIROC")[, "PIJE 97.5%"],
                         "CNTRL_BA" = Median_BA("SJ", "CNTRL")[, "PIJE"],
                         "CNTRL_Dens" = Median_Dens("SJ", "CNTRL")[, "PIJE"],
                         "CNTRL_2.5_BA" = Quant_BA("SJ", "CNTRL")[, "PIJE 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "PIJE 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SJ", "CNTRL")[, "PIJE 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "PIJE 97.5%"])

SJ.PILA.df <- data.frame("Year" = Median_BA("SJ", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SJ", "CCSM4")[, "PILA"],
                         "CCSM4_Dens" = Median_Dens("SJ", "CCSM4")[, "PILA"],
                         "CCSM4_2.5_BA" = Quant_BA("SJ", "CCSM4")[, "PILA 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "PILA 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SJ", "CCSM4")[, "PILA 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SJ", "CCSM4")[, "PILA 97.5%"],
                         "CNRM_BA" = Median_BA("SJ", "CNRM")[, "PILA"],
                         "CNRM_Dens" = Median_Dens("SJ", "CNRM")[, "PILA"],
                         "CNRM_2.5_BA" = Quant_BA("SJ", "CNRM")[, "PILA 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SJ", "CNRM")[, "PILA 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SJ", "CNRM")[, "PILA 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SJ", "CNRM")[, "PILA 97.5%"],
                         "MIROC_BA" = Median_BA("SJ", "MIROC")[, "PILA"],
                         "MIROC_Dens" = Median_Dens("SJ", "MIROC")[, "PILA"],
                         "MIROC_2.5_BA" = Quant_BA("SJ", "MIROC")[, "PILA 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SJ", "MIROC")[, "PILA 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SJ", "MIROC")[, "PILA 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SJ", "MIROC")[, "PILA 97.5%"],
                         "CNTRL_BA" = Median_BA("SJ", "CNTRL")[, "PILA"],
                         "CNTRL_Dens" = Median_Dens("SJ", "CNTRL")[, "PILA"],
                         "CNTRL_2.5_BA" = Quant_BA("SJ", "CNTRL")[, "PILA 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "PILA 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SJ", "CNTRL")[, "PILA 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SJ", "CNTRL")[, "PILA 97.5%"])
##################################################################
#SJP: ABCO, CADE, PIJE, PILA, PIPO, ABMA

SJP.ABCO.df <- data.frame("Year" = Median_BA("SJP", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJP", "CCSM4")[, "ABCO"],
                          "CCSM4_Dens" = Median_Dens("SJP", "CCSM4")[, "ABCO"],
                          "CCSM4_2.5_BA" = Quant_BA("SJP", "CCSM4")[, "ABCO 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "ABCO 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJP", "CCSM4")[, "ABCO 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "ABCO 97.5%"],
                          "CNRM_BA" = Median_BA("SJP", "CNRM")[, "ABCO"],
                          "CNRM_Dens" = Median_Dens("SJP", "CNRM")[, "ABCO"],
                          "CNRM_2.5_BA" = Quant_BA("SJP", "CNRM")[, "ABCO 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJP", "CNRM")[, "ABCO 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJP", "CNRM")[, "ABCO 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJP", "CNRM")[, "ABCO 97.5%"],
                          "MIROC_BA" = Median_BA("SJP", "MIROC")[, "ABCO"],
                          "MIROC_Dens" = Median_Dens("SJP", "MIROC")[, "ABCO"],
                          "MIROC_2.5_BA" = Quant_BA("SJP", "MIROC")[, "ABCO 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJP", "MIROC")[, "ABCO 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJP", "MIROC")[, "ABCO 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJP", "MIROC")[, "ABCO 97.5%"],
                          "CNTRL_BA" = Median_BA("SJP", "CNTRL")[, "ABCO"],
                          "CNTRL_Dens" = Median_Dens("SJP", "CNTRL")[, "ABCO"],
                          "CNTRL_2.5_BA" = Quant_BA("SJP", "CNTRL")[, "ABCO 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "ABCO 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJP", "CNTRL")[, "ABCO 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "ABCO 97.5%"])

SJP.ABMA.df <- data.frame("Year" = Median_BA("SJP", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJP", "CCSM4")[, "ABMA"],
                          "CCSM4_Dens" = Median_Dens("SJP", "CCSM4")[, "ABMA"],
                          "CCSM4_2.5_BA" = Quant_BA("SJP", "CCSM4")[, "ABMA 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "ABMA 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJP", "CCSM4")[, "ABMA 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "ABMA 97.5%"],
                          "CNRM_BA" = Median_BA("SJP", "CNRM")[, "ABMA"],
                          "CNRM_Dens" = Median_Dens("SJP", "CNRM")[, "ABMA"],
                          "CNRM_2.5_BA" = Quant_BA("SJP", "CNRM")[, "ABMA 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJP", "CNRM")[, "ABMA 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJP", "CNRM")[, "ABMA 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJP", "CNRM")[, "ABMA 97.5%"],
                          "MIROC_BA" = Median_BA("SJP", "MIROC")[, "ABMA"],
                          "MIROC_Dens" = Median_Dens("SJP", "MIROC")[, "ABMA"],
                          "MIROC_2.5_BA" = Quant_BA("SJP", "MIROC")[, "ABMA 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJP", "MIROC")[, "ABMA 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJP", "MIROC")[, "ABMA 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJP", "MIROC")[, "ABMA 97.5%"],
                          "CNTRL_BA" = Median_BA("SJP", "CNTRL")[, "ABMA"],
                          "CNTRL_Dens" = Median_Dens("SJP", "CNTRL")[, "ABMA"],
                          "CNTRL_2.5_BA" = Quant_BA("SJP", "CNTRL")[, "ABMA 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "ABMA 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJP", "CNTRL")[, "ABMA 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "ABMA 97.5%"])

SJP.PIJE.df <- data.frame("Year" = Median_BA("SJP", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJP", "CCSM4")[, "PIJE"],
                          "CCSM4_Dens" = Median_Dens("SJP", "CCSM4")[, "PIJE"],
                          "CCSM4_2.5_BA" = Quant_BA("SJP", "CCSM4")[, "PIJE 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "PIJE 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJP", "CCSM4")[, "PIJE 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "PIJE 97.5%"],
                          "CNRM_BA" = Median_BA("SJP", "CNRM")[, "PIJE"],
                          "CNRM_Dens" = Median_Dens("SJP", "CNRM")[, "PIJE"],
                          "CNRM_2.5_BA" = Quant_BA("SJP", "CNRM")[, "PIJE 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJP", "CNRM")[, "PIJE 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJP", "CNRM")[, "PIJE 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJP", "CNRM")[, "PIJE 97.5%"],
                          "MIROC_BA" = Median_BA("SJP", "MIROC")[, "PIJE"],
                          "MIROC_Dens" = Median_Dens("SJP", "MIROC")[, "PIJE"],
                          "MIROC_2.5_BA" = Quant_BA("SJP", "MIROC")[, "PIJE 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJP", "MIROC")[, "PIJE 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJP", "MIROC")[, "PIJE 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJP", "MIROC")[, "PIJE 97.5%"],
                          "CNTRL_BA" = Median_BA("SJP", "CNTRL")[, "PIJE"],
                          "CNTRL_Dens" = Median_Dens("SJP", "CNTRL")[, "PIJE"],
                          "CNTRL_2.5_BA" = Quant_BA("SJP", "CNTRL")[, "PIJE 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "PIJE 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJP", "CNTRL")[, "PIJE 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "PIJE 97.5%"])

SJP.PILA.df <- data.frame("Year" = Median_BA("SJP", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJP", "CCSM4")[, "PILA"],
                          "CCSM4_Dens" = Median_Dens("SJP", "CCSM4")[, "PILA"],
                          "CCSM4_2.5_BA" = Quant_BA("SJP", "CCSM4")[, "PILA 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "PILA 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJP", "CCSM4")[, "PILA 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "PILA 97.5%"],
                          "CNRM_BA" = Median_BA("SJP", "CNRM")[, "PILA"],
                          "CNRM_Dens" = Median_Dens("SJP", "CNRM")[, "PILA"],
                          "CNRM_2.5_BA" = Quant_BA("SJP", "CNRM")[, "PILA 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJP", "CNRM")[, "PILA 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJP", "CNRM")[, "PILA 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJP", "CNRM")[, "PILA 97.5%"],
                          "MIROC_BA" = Median_BA("SJP", "MIROC")[, "PILA"],
                          "MIROC_Dens" = Median_Dens("SJP", "MIROC")[, "PILA"],
                          "MIROC_2.5_BA" = Quant_BA("SJP", "MIROC")[, "PILA 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJP", "MIROC")[, "PILA 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJP", "MIROC")[, "PILA 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJP", "MIROC")[, "PILA 97.5%"],
                          "CNTRL_BA" = Median_BA("SJP", "CNTRL")[, "PILA"],
                          "CNTRL_Dens" = Median_Dens("SJP", "CNTRL")[, "PILA"],
                          "CNTRL_2.5_BA" = Quant_BA("SJP", "CNTRL")[, "PILA 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "PILA 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJP", "CNTRL")[, "PILA 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "PILA 97.5%"])

SJP.CADE.df <- data.frame("Year" = Median_BA("SJP", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJP", "CCSM4")[, "CADE"],
                          "CCSM4_Dens" = Median_Dens("SJP", "CCSM4")[, "CADE"],
                          "CCSM4_2.5_BA" = Quant_BA("SJP", "CCSM4")[, "CADE 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "CADE 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJP", "CCSM4")[, "CADE 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "CADE 97.5%"],
                          "CNRM_BA" = Median_BA("SJP", "CNRM")[, "CADE"],
                          "CNRM_Dens" = Median_Dens("SJP", "CNRM")[, "CADE"],
                          "CNRM_2.5_BA" = Quant_BA("SJP", "CNRM")[, "CADE 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJP", "CNRM")[, "CADE 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJP", "CNRM")[, "CADE 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJP", "CNRM")[, "CADE 97.5%"],
                          "MIROC_BA" = Median_BA("SJP", "MIROC")[, "CADE"],
                          "MIROC_Dens" = Median_Dens("SJP", "MIROC")[, "CADE"],
                          "MIROC_2.5_BA" = Quant_BA("SJP", "MIROC")[, "CADE 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJP", "MIROC")[, "CADE 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJP", "MIROC")[, "CADE 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJP", "MIROC")[, "CADE 97.5%"],
                          "CNTRL_BA" = Median_BA("SJP", "CNTRL")[, "CADE"],
                          "CNTRL_Dens" = Median_Dens("SJP", "CNTRL")[, "CADE"],
                          "CNTRL_2.5_BA" = Quant_BA("SJP", "CNTRL")[, "CADE 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "CADE 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJP", "CNTRL")[, "CADE 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "CADE 97.5%"])

SJP.PIPO.df <- data.frame("Year" = Median_BA("SJP", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJP", "CCSM4")[, "PIPO"],
                          "CCSM4_Dens" = Median_Dens("SJP", "CCSM4")[, "PIPO"],
                          "CCSM4_2.5_BA" = Quant_BA("SJP", "CCSM4")[, "PIPO 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "PIPO 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJP", "CCSM4")[, "PIPO 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJP", "CCSM4")[, "PIPO 97.5%"],
                          "CNRM_BA" = Median_BA("SJP", "CNRM")[, "PIPO"],
                          "CNRM_Dens" = Median_Dens("SJP", "CNRM")[, "PIPO"],
                          "CNRM_2.5_BA" = Quant_BA("SJP", "CNRM")[, "PIPO 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJP", "CNRM")[, "PIPO 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJP", "CNRM")[, "PIPO 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJP", "CNRM")[, "PIPO 97.5%"],
                          "MIROC_BA" = Median_BA("SJP", "MIROC")[, "PIPO"],
                          "MIROC_Dens" = Median_Dens("SJP", "MIROC")[, "PIPO"],
                          "MIROC_2.5_BA" = Quant_BA("SJP", "MIROC")[, "PIPO 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJP", "MIROC")[, "PIPO 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJP", "MIROC")[, "PIPO 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJP", "MIROC")[, "PIPO 97.5%"],
                          "CNTRL_BA" = Median_BA("SJP", "CNTRL")[, "PIPO"],
                          "CNTRL_Dens" = Median_Dens("SJP", "CNTRL")[, "PIPO"],
                          "CNTRL_2.5_BA" = Quant_BA("SJP", "CNTRL")[, "PIPO 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "PIPO 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJP", "CNTRL")[, "PIPO 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJP", "CNTRL")[, "PIPO 97.5%"])

##################################################################
#SJM: ABCO, ABMA, PICO, PIMO

SJM.ABCO.df <- data.frame("Year" = Median_BA("SJM", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJM", "CCSM4")[, "ABCO"],
                          "CCSM4_Dens" = Median_Dens("SJM", "CCSM4")[, "ABCO"],
                          "CCSM4_2.5_BA" = Quant_BA("SJM", "CCSM4")[, "ABCO 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "ABCO 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJM", "CCSM4")[, "ABCO 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "ABCO 97.5%"],
                          "CNRM_BA" = Median_BA("SJM", "CNRM")[, "ABCO"],
                          "CNRM_Dens" = Median_Dens("SJM", "CNRM")[, "ABCO"],
                          "CNRM_2.5_BA" = Quant_BA("SJM", "CNRM")[, "ABCO 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJM", "CNRM")[, "ABCO 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJM", "CNRM")[, "ABCO 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJM", "CNRM")[, "ABCO 97.5%"],
                          "MIROC_BA" = Median_BA("SJM", "MIROC")[, "ABCO"],
                          "MIROC_Dens" = Median_Dens("SJM", "MIROC")[, "ABCO"],
                          "MIROC_2.5_BA" = Quant_BA("SJM", "MIROC")[, "ABCO 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJM", "MIROC")[, "ABCO 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJM", "MIROC")[, "ABCO 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJM", "MIROC")[, "ABCO 97.5%"],
                          "CNTRL_BA" = Median_BA("SJM", "CNTRL")[, "ABCO"],
                          "CNTRL_Dens" = Median_Dens("SJM", "CNTRL")[, "ABCO"],
                          "CNTRL_2.5_BA" = Quant_BA("SJM", "CNTRL")[, "ABCO 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "ABCO 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJM", "CNTRL")[, "ABCO 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "ABCO 97.5%"])

SJM.ABMA.df <- data.frame("Year" = Median_BA("SJM", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJM", "CCSM4")[, "ABMA"],
                          "CCSM4_Dens" = Median_Dens("SJM", "CCSM4")[, "ABMA"],
                          "CCSM4_2.5_BA" = Quant_BA("SJM", "CCSM4")[, "ABMA 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "ABMA 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJM", "CCSM4")[, "ABMA 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "ABMA 97.5%"],
                          "CNRM_BA" = Median_BA("SJM", "CNRM")[, "ABMA"],
                          "CNRM_Dens" = Median_Dens("SJM", "CNRM")[, "ABMA"],
                          "CNRM_2.5_BA" = Quant_BA("SJM", "CNRM")[, "ABMA 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJM", "CNRM")[, "ABMA 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJM", "CNRM")[, "ABMA 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJM", "CNRM")[, "ABMA 97.5%"],
                          "MIROC_BA" = Median_BA("SJM", "MIROC")[, "ABMA"],
                          "MIROC_Dens" = Median_Dens("SJM", "MIROC")[, "ABMA"],
                          "MIROC_2.5_BA" = Quant_BA("SJM", "MIROC")[, "ABMA 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJM", "MIROC")[, "ABMA 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJM", "MIROC")[, "ABMA 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJM", "MIROC")[, "ABMA 97.5%"],
                          "CNTRL_BA" = Median_BA("SJM", "CNTRL")[, "ABMA"],
                          "CNTRL_Dens" = Median_Dens("SJM", "CNTRL")[, "ABMA"],
                          "CNTRL_2.5_BA" = Quant_BA("SJM", "CNTRL")[, "ABMA 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "ABMA 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJM", "CNTRL")[, "ABMA 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "ABMA 97.5%"])

SJM.PIMO.df <- data.frame("Year" = Median_BA("SJM", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJM", "CCSM4")[, "PIMO"],
                          "CCSM4_Dens" = Median_Dens("SJM", "CCSM4")[, "PIMO"],
                          "CCSM4_2.5_BA" = Quant_BA("SJM", "CCSM4")[, "PIMO 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "PIMO 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJM", "CCSM4")[, "PIMO 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "PIMO 97.5%"],
                          "CNRM_BA" = Median_BA("SJM", "CNRM")[, "PIMO"],
                          "CNRM_Dens" = Median_Dens("SJM", "CNRM")[, "PIMO"],
                          "CNRM_2.5_BA" = Quant_BA("SJM", "CNRM")[, "PIMO 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJM", "CNRM")[, "PIMO 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJM", "CNRM")[, "PIMO 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJM", "CNRM")[, "PIMO 97.5%"],
                          "MIROC_BA" = Median_BA("SJM", "MIROC")[, "PIMO"],
                          "MIROC_Dens" = Median_Dens("SJM", "MIROC")[, "PIMO"],
                          "MIROC_2.5_BA" = Quant_BA("SJM", "MIROC")[, "PIMO 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJM", "MIROC")[, "PIMO 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJM", "MIROC")[, "PIMO 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJM", "MIROC")[, "PIMO 97.5%"],
                          "CNTRL_BA" = Median_BA("SJM", "CNTRL")[, "PIMO"],
                          "CNTRL_Dens" = Median_Dens("SJM", "CNTRL")[, "PIMO"],
                          "CNTRL_2.5_BA" = Quant_BA("SJM", "CNTRL")[, "PIMO 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "PIMO 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJM", "CNTRL")[, "PIMO 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "PIMO 97.5%"])

SJM.PICO.df <- data.frame("Year" = Median_BA("SJM", "MIROC")[, "Years"],
                          "CCSM4_BA" = Median_BA("SJM", "CCSM4")[, "PICO"],
                          "CCSM4_Dens" = Median_Dens("SJM", "CCSM4")[, "PICO"],
                          "CCSM4_2.5_BA" = Quant_BA("SJM", "CCSM4")[, "PICO 2.5%"],
                          "CCSM4_2.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "PICO 2.5%"],
                          "CCSM4_97.5_BA" = Quant_BA("SJM", "CCSM4")[, "PICO 97.5%"],
                          "CCSM4_97.5_Dens" = Quant_Dens("SJM", "CCSM4")[, "PICO 97.5%"],
                          "CNRM_BA" = Median_BA("SJM", "CNRM")[, "PICO"],
                          "CNRM_Dens" = Median_Dens("SJM", "CNRM")[, "PICO"],
                          "CNRM_2.5_BA" = Quant_BA("SJM", "CNRM")[, "PICO 2.5%"],
                          "CNRM_2.5_Dens" = Quant_Dens("SJM", "CNRM")[, "PICO 2.5%"],
                          "CNRM_97.5_BA" = Quant_BA("SJM", "CNRM")[, "PICO 97.5%"],
                          "CNRM_97.5_Dens" = Quant_Dens("SJM", "CNRM")[, "PICO 97.5%"],
                          "MIROC_BA" = Median_BA("SJM", "MIROC")[, "PICO"],
                          "MIROC_Dens" = Median_Dens("SJM", "MIROC")[, "PICO"],
                          "MIROC_2.5_BA" = Quant_BA("SJM", "MIROC")[, "PICO 2.5%"],
                          "MIROC_2.5_Dens" = Quant_Dens("SJM", "MIROC")[, "PICO 2.5%"],
                          "MIROC_97.5_BA" = Quant_BA("SJM", "MIROC")[, "PICO 97.5%"],
                          "MIROC_97.5_Dens" = Quant_Dens("SJM", "MIROC")[, "PICO 97.5%"],
                          "CNTRL_BA" = Median_BA("SJM", "CNTRL")[, "PICO"],
                          "CNTRL_Dens" = Median_Dens("SJM", "CNTRL")[, "PICO"],
                          "CNTRL_2.5_BA" = Quant_BA("SJM", "CNTRL")[, "PICO 2.5%"],
                          "CNTRL_2.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "PICO 2.5%"],
                          "CNTRL_97.5_BA" = Quant_BA("SJM", "CNTRL")[, "PICO 97.5%"],
                          "CNTRL_97.5_Dens" = Quant_Dens("SJM", "CNTRL")[, "PICO 97.5%"])


##################################################################
#SP: ABCO, CADE, PILA, PIPO, QUCH, QUKE

SP.ABCO.df <- data.frame("Year" = Median_BA("SP", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SP", "CCSM4")[, "ABCO"],
                         "CCSM4_Dens" = Median_Dens("SP", "CCSM4")[, "ABCO"],
                         "CCSM4_2.5_BA" = Quant_BA("SP", "CCSM4")[, "ABCO 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SP", "CCSM4")[, "ABCO 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SP", "CCSM4")[, "ABCO 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SP", "CCSM4")[, "ABCO 97.5%"],
                         "CNRM_BA" = Median_BA("SP", "CNRM")[, "ABCO"],
                         "CNRM_Dens" = Median_Dens("SP", "CNRM")[, "ABCO"],
                         "CNRM_2.5_BA" = Quant_BA("SP", "CNRM")[, "ABCO 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SP", "CNRM")[, "ABCO 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SP", "CNRM")[, "ABCO 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SP", "CNRM")[, "ABCO 97.5%"],
                         "MIROC_BA" = Median_BA("SP", "MIROC")[, "ABCO"],
                         "MIROC_Dens" = Median_Dens("SP", "MIROC")[, "ABCO"],
                         "MIROC_2.5_BA" = Quant_BA("SP", "MIROC")[, "ABCO 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SP", "MIROC")[, "ABCO 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SP", "MIROC")[, "ABCO 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SP", "MIROC")[, "ABCO 97.5%"],
                         "CNTRL_BA" = Median_BA("SP", "CNTRL")[, "ABCO"],
                         "CNTRL_Dens" = Median_Dens("SP", "CNTRL")[, "ABCO"],
                         "CNTRL_2.5_BA" = Quant_BA("SP", "CNTRL")[, "ABCO 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SP", "CNTRL")[, "ABCO 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SP", "CNTRL")[, "ABCO 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SP", "CNTRL")[, "ABCO 97.5%"])

SP.CADE.df <- data.frame("Year" = Median_BA("SP", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SP", "CCSM4")[, "CADE"],
                         "CCSM4_Dens" = Median_Dens("SP", "CCSM4")[, "CADE"],
                         "CCSM4_2.5_BA" = Quant_BA("SP", "CCSM4")[, "CADE 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SP", "CCSM4")[, "CADE 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SP", "CCSM4")[, "CADE 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SP", "CCSM4")[, "CADE 97.5%"],
                         "CNRM_BA" = Median_BA("SP", "CNRM")[, "CADE"],
                         "CNRM_Dens" = Median_Dens("SP", "CNRM")[, "CADE"],
                         "CNRM_2.5_BA" = Quant_BA("SP", "CNRM")[, "CADE 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SP", "CNRM")[, "CADE 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SP", "CNRM")[, "CADE 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SP", "CNRM")[, "CADE 97.5%"],
                         "MIROC_BA" = Median_BA("SP", "MIROC")[, "CADE"],
                         "MIROC_Dens" = Median_Dens("SP", "MIROC")[, "CADE"],
                         "MIROC_2.5_BA" = Quant_BA("SP", "MIROC")[, "CADE 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SP", "MIROC")[, "CADE 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SP", "MIROC")[, "CADE 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SP", "MIROC")[, "CADE 97.5%"],
                         "CNTRL_BA" = Median_BA("SP", "CNTRL")[, "CADE"],
                         "CNTRL_Dens" = Median_Dens("SP", "CNTRL")[, "CADE"],
                         "CNTRL_2.5_BA" = Quant_BA("SP", "CNTRL")[, "CADE 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SP", "CNTRL")[, "CADE 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SP", "CNTRL")[, "CADE 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SP", "CNTRL")[, "CADE 97.5%"])

SP.PIPO.df <- data.frame("Year" = Median_BA("SP", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SP", "CCSM4")[, "PIPO"],
                         "CCSM4_Dens" = Median_Dens("SP", "CCSM4")[, "PIPO"],
                         "CCSM4_2.5_BA" = Quant_BA("SP", "CCSM4")[, "PIPO 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SP", "CCSM4")[, "PIPO 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SP", "CCSM4")[, "PIPO 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SP", "CCSM4")[, "PIPO 97.5%"],
                         "CNRM_BA" = Median_BA("SP", "CNRM")[, "PIPO"],
                         "CNRM_Dens" = Median_Dens("SP", "CNRM")[, "PIPO"],
                         "CNRM_2.5_BA" = Quant_BA("SP", "CNRM")[, "PIPO 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SP", "CNRM")[, "PIPO 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SP", "CNRM")[, "PIPO 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SP", "CNRM")[, "PIPO 97.5%"],
                         "MIROC_BA" = Median_BA("SP", "MIROC")[, "PIPO"],
                         "MIROC_Dens" = Median_Dens("SP", "MIROC")[, "PIPO"],
                         "MIROC_2.5_BA" = Quant_BA("SP", "MIROC")[, "PIPO 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SP", "MIROC")[, "PIPO 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SP", "MIROC")[, "PIPO 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SP", "MIROC")[, "PIPO 97.5%"],
                         "CNTRL_BA" = Median_BA("SP", "CNTRL")[, "PIPO"],
                         "CNTRL_Dens" = Median_Dens("SP", "CNTRL")[, "PIPO"],
                         "CNTRL_2.5_BA" = Quant_BA("SP", "CNTRL")[, "PIPO 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SP", "CNTRL")[, "PIPO 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SP", "CNTRL")[, "PIPO 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SP", "CNTRL")[, "PIPO 97.5%"])

SP.PILA.df <- data.frame("Year" = Median_BA("SP", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SP", "CCSM4")[, "PILA"],
                         "CCSM4_Dens" = Median_Dens("SP", "CCSM4")[, "PILA"],
                         "CCSM4_2.5_BA" = Quant_BA("SP", "CCSM4")[, "PILA 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SP", "CCSM4")[, "PILA 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SP", "CCSM4")[, "PILA 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SP", "CCSM4")[, "PILA 97.5%"],
                         "CNRM_BA" = Median_BA("SP", "CNRM")[, "PILA"],
                         "CNRM_Dens" = Median_Dens("SP", "CNRM")[, "PILA"],
                         "CNRM_2.5_BA" = Quant_BA("SP", "CNRM")[, "PILA 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SP", "CNRM")[, "PILA 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SP", "CNRM")[, "PILA 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SP", "CNRM")[, "PILA 97.5%"],
                         "MIROC_BA" = Median_BA("SP", "MIROC")[, "PILA"],
                         "MIROC_Dens" = Median_Dens("SP", "MIROC")[, "PILA"],
                         "MIROC_2.5_BA" = Quant_BA("SP", "MIROC")[, "PILA 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SP", "MIROC")[, "PILA 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SP", "MIROC")[, "PILA 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SP", "MIROC")[, "PILA 97.5%"],
                         "CNTRL_BA" = Median_BA("SP", "CNTRL")[, "PILA"],
                         "CNTRL_Dens" = Median_Dens("SP", "CNTRL")[, "PILA"],
                         "CNTRL_2.5_BA" = Quant_BA("SP", "CNTRL")[, "PILA 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SP", "CNTRL")[, "PILA 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SP", "CNTRL")[, "PILA 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SP", "CNTRL")[, "PILA 97.5%"])

SP.QUCH.df <- data.frame("Year" = Median_BA("SP", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SP", "CCSM4")[, "QUCH"],
                         "CCSM4_Dens" = Median_Dens("SP", "CCSM4")[, "QUCH"],
                         "CCSM4_2.5_BA" = Quant_BA("SP", "CCSM4")[, "QUCH 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SP", "CCSM4")[, "QUCH 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SP", "CCSM4")[, "QUCH 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SP", "CCSM4")[, "QUCH 97.5%"],
                         "CNRM_BA" = Median_BA("SP", "CNRM")[, "QUCH"],
                         "CNRM_Dens" = Median_Dens("SP", "CNRM")[, "QUCH"],
                         "CNRM_2.5_BA" = Quant_BA("SP", "CNRM")[, "QUCH 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SP", "CNRM")[, "QUCH 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SP", "CNRM")[, "QUCH 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SP", "CNRM")[, "QUCH 97.5%"],
                         "MIROC_BA" = Median_BA("SP", "MIROC")[, "QUCH"],
                         "MIROC_Dens" = Median_Dens("SP", "MIROC")[, "QUCH"],
                         "MIROC_2.5_BA" = Quant_BA("SP", "MIROC")[, "QUCH 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SP", "MIROC")[, "QUCH 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SP", "MIROC")[, "QUCH 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SP", "MIROC")[, "QUCH 97.5%"],
                         "CNTRL_BA" = Median_BA("SP", "CNTRL")[, "QUCH"],
                         "CNTRL_Dens" = Median_Dens("SP", "CNTRL")[, "QUCH"],
                         "CNTRL_2.5_BA" = Quant_BA("SP", "CNTRL")[, "QUCH 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SP", "CNTRL")[, "QUCH 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SP", "CNTRL")[, "QUCH 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SP", "CNTRL")[, "QUCH 97.5%"])

SP.QUKE.df <- data.frame("Year" = Median_BA("SP", "MIROC")[, "Years"],
                         "CCSM4_BA" = Median_BA("SP", "CCSM4")[, "QUKE"],
                         "CCSM4_Dens" = Median_Dens("SP", "CCSM4")[, "QUKE"],
                         "CCSM4_2.5_BA" = Quant_BA("SP", "CCSM4")[, "QUKE 2.5%"],
                         "CCSM4_2.5_Dens" = Quant_Dens("SP", "CCSM4")[, "QUKE 2.5%"],
                         "CCSM4_97.5_BA" = Quant_BA("SP", "CCSM4")[, "QUKE 97.5%"],
                         "CCSM4_97.5_Dens" = Quant_Dens("SP", "CCSM4")[, "QUKE 97.5%"],
                         "CNRM_BA" = Median_BA("SP", "CNRM")[, "QUKE"],
                         "CNRM_Dens" = Median_Dens("SP", "CNRM")[, "QUKE"],
                         "CNRM_2.5_BA" = Quant_BA("SP", "CNRM")[, "QUKE 2.5%"],
                         "CNRM_2.5_Dens" = Quant_Dens("SP", "CNRM")[, "QUKE 2.5%"],
                         "CNRM_97.5_BA" = Quant_BA("SP", "CNRM")[, "QUKE 97.5%"],
                         "CNRM_97.5_Dens" = Quant_Dens("SP", "CNRM")[, "QUKE 97.5%"],
                         "MIROC_BA" = Median_BA("SP", "MIROC")[, "QUKE"],
                         "MIROC_Dens" = Median_Dens("SP", "MIROC")[, "QUKE"],
                         "MIROC_2.5_BA" = Quant_BA("SP", "MIROC")[, "QUKE 2.5%"],
                         "MIROC_2.5_Dens" = Quant_Dens("SP", "MIROC")[, "QUKE 2.5%"],
                         "MIROC_97.5_BA" = Quant_BA("SP", "MIROC")[, "QUKE 97.5%"],
                         "MIROC_97.5_Dens" = Quant_Dens("SP", "MIROC")[, "QUKE 97.5%"],
                         "CNTRL_BA" = Median_BA("SP", "CNTRL")[, "QUKE"],
                         "CNTRL_Dens" = Median_Dens("SP", "CNTRL")[, "QUKE"],
                         "CNTRL_2.5_BA" = Quant_BA("SP", "CNTRL")[, "QUKE 2.5%"],
                         "CNTRL_2.5_Dens" = Quant_Dens("SP", "CNTRL")[, "QUKE 2.5%"],
                         "CNTRL_97.5_BA" = Quant_BA("SP", "CNTRL")[, "QUKE 97.5%"],
                         "CNTRL_97.5_Dens" = Quant_Dens("SP", "CNTRL")[, "QUKE 97.5%"])